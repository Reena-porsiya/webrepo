export const environment = {
    production: false, // Set to true for production
  };
  