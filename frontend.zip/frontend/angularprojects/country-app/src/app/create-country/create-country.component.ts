// Import necessary modules from Angular
import { Component } from '@angular/core';

// Decorate the CreateCountryComponent class with @Component decorator
@Component({
  selector: 'app-create-country',
  templateUrl: './create-country.component.html',
  styleUrls: ['./create-country.component.css']
})
export class CreateCountryComponent {
  // Initialize country object with empty values
  country = { iataCountryCode: '', name: '' };

  // Method to handle form submission
  onSubmit() {
    // Log the form data to the console (for demonstration purposes)
    console.log('Form submitted:', this.country);
    // You can implement your form submission logic here
  }
}
