export interface Country {
  iataCountryCode: string;
  name: string;
}
